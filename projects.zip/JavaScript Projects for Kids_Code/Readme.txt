Chapter 2 - No code
Chapter 3 - No code
Chapter 4 - No code
Chapter 10 - No code